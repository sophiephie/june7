package Activity1;

public class activity1two {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=74;
		int y=36;
		System.out.print(x + y);
				
	}

}
