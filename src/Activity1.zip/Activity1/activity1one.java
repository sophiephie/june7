package Activity1;

public class activity1one {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello");
		System.out.print("Sophie Hsu");

	}

}
