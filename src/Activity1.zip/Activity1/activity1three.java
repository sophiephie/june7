package Activity1;

public class activity1three {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=50;
		int y=3;
		System.out.println(x/y);
		
		int a=125;
		int b=24;
		System.out.print(a/b);
		
		

	}

}
