package Activity1;

public class activity1seven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(" +\"\"\"\"\"+ ");
		System.out.println("[| o o |]");
		System.out.println(" |  ^  | ");
		System.out.println(" | '-' | ");
		System.out.println(" +-----+ ");
		
		

	}

}
