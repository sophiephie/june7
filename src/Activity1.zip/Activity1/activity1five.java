package Activity1;

import java.util.Scanner;

public class activity1five {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Input a number");
		Scanner kb = new Scanner(System.in);
		int one = kb.nextInt();
		System.out.println("Input another number");
		int two = kb.nextInt();
		System.out.println("Input last number");
		int last = kb.nextInt();
		
		System.out.println("Your sum is " + (one + two + last));
		
		
		
		
		

		
		
				
				
				
			

	}

}
